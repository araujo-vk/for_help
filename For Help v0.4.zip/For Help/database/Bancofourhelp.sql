create database fourhelp;
use fourhelp;

-- FOR HELP "Trabalho para a Bartotec ETEC Bratolomeu Bueno Da Silva 2025" --
/* -- Integrantes e Turma --
Membros: 
Anna Alice Alustau Siqueira
Giovanni Oliveira Obata
Lorenzo Marques Alves
Victor Oliveira Araújo

2° Informática para Internet - AMS - Grupo A
*/

/* -- Ideias centrais trabalhadas no Projeto --

! --> Plataforma onde jovens podem buscar contato melhor com empresas e buscar emprego 
! --> Caso tenhamos tempo, integrar no projeto um sistema de cursos

 >>> Tabelas: <<<

==> cliente {adm aqui}
==> empresa
==> vagas
==> geral

caso dê tempo:
	-> cursos
	-> docentes
*/

create table cliente (
id_cliente int not null auto_increment primary key,
nome_cliente varchar(128),
email_cliente varchar(128) not null,
username_cliente varchar(48) unique not null,
telefone_cliente varchar(15),
senha_cliente varchar(32) not null,
idade_cliente date,
curriculo_cliente varchar(64), -- arquivo
cursos_cliente varchar(256), -- arquivo(certificado) ou link, o back decide
if_admin bool -- ADMIN
);

create table empresa (
id_empresa int not null auto_increment primary key,
nome_empresa varchar(128) unique not null,
contato_empresa varchar(128),
cnpj_empresa varchar(18) not null, -- para o front e o back: usar isso para o cadastro + logien
senha_empresa varchar(32) not null,
telefone_empresa varchar(15)
);

create table vaga (
id_vaga int not null auto_increment primary key,
id_cliente int,
id_empresa int,
nome_empresa varchar(128),
area_vaga varchar(64),
sub_area_vaga varchar(64),
descricao_vaga text,
detalhes_vaga longtext,
req1 varchar(128),
req2 varchar(128),
req3 varchar(128),
foreign key (id_cliente) references cliente(id_cliente),
foreign key (id_empresa) references empresa(id_empresa)
);

create table educador (
id_educador int not null auto_increment primary key,
nome_educador varchar(128) not null,
email_educador varchar(128) not null,
senha_educador varchar(32) not null
);

create table curso (
id_curso int not null auto_increment primary key,
id_educador int,
nome_curso varchar(128) not null,
area_curso varchar(64),
sub_area_curso varchar(64),
horas_curso int,
aulas_curso varchar(128),
link_curso varchar(256),
foreign key (id_educador) references educador(id_educador)
);

create table denuncias_usuario(
id_denuncia int not null auto_increment primary key,
id_cliente int,
username_cliente varchar(128),
id_empresa int,
nome_empresa varchar(128),
id_educador int,
nome_educador varchar(128),
motivo_denuncia text,
foreign key (id_cliente) references cliente(id_cliente),
foreign key (id_empresa) references empresa(id_empresa),
foreign key (id_educador) references educador(id_educador)
);
select*from vaga;
INSERT INTO empresa(nome_empresa,contato_empresa,cnpj_empresa,senha_empresa,telefone_empresa) values
('Proative', 'proative@gmail.com','12.432.543/4321-45','proative@@545','(11) 94123-4324'),
('TechSolutions BR', 'contato@techsolutions.com.br', '11.222.333/0001-01', 'tech2025@@', '(11) 3456-7890'),
('Inovação Digital', 'rh@inovacaodigital.com.br', '22.333.444/0001-02', 'inova2025@@', '(11) 2345-6789'),
('Green Energy SA', 'careers@greenenergy.com.br', '33.444.555/0001-03', 'green2025@@', '(11) 4567-8901'),
('Construtora Futuro', 'rh@construtorafuturo.com.br', '44.555.666/0001-04', 'futuro2025@@', '(11) 5678-9012'),
('Banco NextGen', 'talentos@banconextgen.com.br', '55.666.777/0001-05', 'next2025@@', '(11) 6789-0123'),
('DataTech Brasil', 'vagas@datatech.com.br', '66.777.888/0001-06', 'data2025@@', '(11) 7890-1234'),
('EcoSustentável', 'trabalhe@ecosustentavel.com.br', '77.888.999/0001-07', 'eco2025@@', '(11) 8901-2345'),
('Logística Express', 'jobs@logisticaexpress.com.br', '88.999.000/0001-08', 'log2025@@', '(11) 9012-3456'),
('EducaTech', 'vagas@educatech.com.br', '99.000.111/0001-09', 'educa2025@@', '(11) 0123-4567'),
('Saúde Integral', 'rh@saudeintegral.com.br', '10.111.222/0001-10', 'saude2025@@', '(11) 1234-5678');

INSERT INTO cliente(nome_cliente,email_cliente,username_cliente,telefone_cliente,senha_cliente,idade_cliente) values
('Lorenzo Marques Alves','lorenzo.alves01@etec.sp.gov.br','Lorenzo','(11) 99181-7819','Lorenzo@@345','2009-01-31'),
('Victor Oliveira Araújo', 'victor.araujo114@etec.sp.gov.br','Victor','(11) 91087-1607','Victor@@9705','2008-11-20');

INSERT INTO vaga (id_empresa, nome_empresa, area_vaga, sub_area_vaga, descricao_vaga, detalhes_vaga, req1, req2, req3) VALUES
(1, 'Proative', 'Tecnologia', 'Desenvolvimento Web', 'Desenvolvedor Full Stack com experiência em React e Node.js. Home Office.',
'Detalhes: Atuará no desenvolvimento e manutenção de aplicações web completas, cobrindo front-end em React e back-end em Node.js. Responsável por criação de APIs REST, integração com bancos relacionais, otimização de performance e participação em code review. Trabalho em equipes ágeis, entrega contínua (CI/CD) e documentação técnica. Oferecemos plano de crescimento, ambiente colaborativo e oportunidades de treinamento contínuo para evolução profissional.',
'Formação em TI ou área relacionada','3+ anos em desenvolvimento web full stack','Conhecimento em React, Node.js e SQL'),
(2, 'TechSolutions BR', 'Marketing', 'Marketing Digital', 'Analista de Marketing Digital para gestão de redes sociais e campanhas.',
'Detalhes: Responsável por planejar, executar e otimizar campanhas digitais (Google Ads, Facebook/Instagram Ads), gestão de redes sociais, análise de métricas e geração de relatórios. Trabalhará em conjunto com design e conteúdo para criação de peças e estratégias de conversão, A/B tests e funil de vendas. Espera-se habilidade em ferramentas de automação, SEO on-page e mindset orientado a dados para melhorar CPL/CPA e ROI.',
'Experiência em Ads e SEO','Habilidade com ferramentas de analytics','Bom relacionamento e comunicação'),
(3, 'Inovação Digital', 'Engenharia', 'Energia Renovável', 'Engenheiro de Projetos para instalação de painéis solares.',
'Detalhes: Responsável pelo dimensionamento técnico, elaboração de projetos e especificações para instalações solares fotovoltaicas residenciais e comerciais. Atuação inclui visitas técnicas, estudos de viabilidade, interface com fornecedores, acompanhamento de montagem e testes finais, além de emissão de relatórios técnicos. Necessário conhecimento em normas técnicas, segurança do trabalho, e capacidade de planejar cronogramas garantindo qualidade e custo-benefício.',
'Formação em Engenharia','Conhecimento em sistemas fotovoltaicos','Experiência em projetos e visitas técnicas'),
(4, 'Green Energy SA', 'Construção', 'Arquitetura', 'Arquiteto para desenvolvimento de projetos residenciais sustentáveis.',
'Detalhes: Desenvolvimento de projetos arquitetônicos com foco em soluções sustentáveis, eficiência energética e uso de materiais eco-friendly. Atuação desde estudo preliminar até detalhamento executivo, coordenação com equipes multidisciplinares e elaboração de maquetes e apresentações para clientes. Espera-se domínio de software CAD/BIM, capacidade crítica para soluções de conforto térmico e acústico e visão orientada à inovação e sustentabilidade.',
'Formação em Arquitetura','Conhecimento em CAD/BIM','Foco em soluções sustentáveis'),
(5, 'Construtora Futuro', 'Financeiro', 'Análise de Dados', 'Analista Financeiro com conhecimento em Power BI e SQL.',
'Detalhes: Atuação voltada a análise financeira, elaboração de dashboards e relatórios gerenciais em Power BI, consulta e modelagem de dados via SQL, projeções orçamentárias e apoio na tomada de decisão estratégica. Responsável por automatizar rotinas, identificar desvios e oportunidades de redução de custos. Trabalho colaborativo com áreas de obras, compras e RH para consolidar indicadores financeiros e operacionais com visão preditiva.',
'Formação em Economia/Finanças/ADM','Conhecimento avançado em Power BI','SQL e modelagem de dados'),
(6, 'Banco NextGen', 'Tecnologia', 'Data Science', 'Cientista de Dados com experiência em Python e Machine Learning.',
'Detalhes: Desenvolvimento e produção de modelos preditivos para crédito, churn e detecção de fraude, usando Python, bibliotecas de ML e pipelines reutilizáveis. Responsável por preparação de dados, engenharia de features, avaliação de modelos e monitoramento pós-deploy. Trabalhará com times de produto e engenharia para transformar modelos em serviços escaláveis e documentados, garantindo governança de dados e conformidade regulatória.',
'Formação em Estatística/CI/Engenharia','Experiência com Python e ML','Conhecimento em modelagem e validação de modelos'),
(7, 'DataTech Brasil', 'Meio Ambiente', 'Gestão Ambiental', 'Analista Ambiental para projetos de sustentabilidade.',
'Detalhes: Atuação em estudos ambientais, relatórios de conformidade, gestão de resíduos e projetos de mitigação ambiental. Responsável por levantamento de impacto, rotinas de monitoramento, interação com órgãos ambientais e implementação de práticas sustentáveis em processos industriais. Espera-se habilidade em análise de dados ambientais, elaboração de laudos e coordenação de iniciativas de educação ambiental junto a stakeholders internos.',
'Formação em Engenharia Ambiental ou similar','Experiência em estudos de impacto','Habilidade com relatórios técnicos'),
(8, 'EcoSustentável', 'Logística', 'Supply Chain', 'Coordenador de Logística para gestão de operações.',
'Detalhes: Gestão completa da cadeia logística, incluindo planejamento de demanda, coordenação de armazenagem, roteirização e controle de custos. Responsável por melhoria de processos, acompanhamento de KPIs, negociação com transportadoras e implementação de tecnologias para rastreabilidade. Trabalho orientado a eficiência, sustentabilidade logística e redução de desperdícios, com interface entre equipes operacionais e comerciais.',
'Experiência em cadeia logística','Conhecimento em WMS/ERP','Habilidade em negociação e planejamento'),
(9, 'Logística Express', 'Educação', 'Tecnologia Educacional', 'Desenvolvedor de Conteúdo EAD e ferramentas educacionais.',
'Detalhes: Criação e manutenção de conteúdos digitais, desenvolvimento de ferramentas interativas para EAD e integração de plataformas LMS. Atividades incluem concepção pedagógica com educadores, criação de roteiros, edição multimídia e testes de usabilidade. Buscamos perfil com entendimento pedagógico, conhecimento técnico em autorias e preocupação com acessibilidade e métricas de engajamento.',
'Experiência com plataformas EAD','Competência em multimídia e UX','Noções pedagógicas e didáticas'),
(10, 'EducaTech', 'Saúde', 'Tecnologia Médica', 'Analista de Sistemas para área hospitalar.',
'Detalhes: Responsável por desenvolvimento e suporte de sistemas para gestão hospitalar, integração com equipamentos médicos e garantia de confidencialidade de dados. Atuação inclui análise de requisitos com equipes clínicas, implementação de melhorias, testes e documentação. Busca-se profissional com conhecimento de normas de saúde, interoperabilidade (HL7/FHIR) e foco em desempenho e segurança em ambientes críticos.',
'Formação em TI com foco em saúde','Conhecimento em HL7/FHIR','Experiência em integração de sistemas'),
(1, 'Proative', 'Tecnologia', 'Mobile', 'Desenvolvedor Mobile para aplicativos iOS e Android.',
'Detalhes: Desenvolvimento de aplicações móveis nativas ou híbridas com foco em performance, usabilidade e integração com APIs. Atuação no ciclo completo do produto, desde prototipagem até deploy em lojas e suporte pós-lançamento. Espera-se práticas de testes automatizados, otimização de recursos, preocupação com segurança de dados e colaboração próxima com design e backend para entrega de soluções consistentes.',
'Experiência em desenvolvimento mobile','Conhecimento em iOS/Android ou frameworks cross-platform','Foco em qualidade e testes'),
(2, 'TechSolutions BR', 'Comercial', 'Vendas', 'Executivo de Vendas para produtos digitais.',
'Detalhes: Prospecção ativa, qualificação de leads, condução de demonstrações e fechamento de contratos para soluções digitais SaaS. Responsável por acompanhamento do funil de vendas, elaboração de propostas comerciais, negociação e atingimento de metas mensais. Ambiente de trabalho dinâmico com comissões atrativas, foco em inteligência comercial e uso de CRM para mensuração de performance.',
'Experiência em vendas B2B','Habilidade em negociação e CRM','Orientação a metas e resultados'),
(3, 'Inovação Digital', 'Engenharia', 'Projetos', 'Gerente de Projetos para instalações industriais.',
'Detalhes: Liderança de projetos industriais com foco em cumprimento de prazos, orçamento e segurança. Coordenação de equipes multidisciplinares, gerenciamento de fornecedores, controle de escopo e mitigação de riscos. Atuação envolve planejamento detalhado, cronogramas, relatórios gerenciais e garantia de conformidade técnica e regulatória, buscando entregas com qualidade e otimização de recursos.',
'Formação em Engenharia','Experiência em gestão de projetos','Certificação em PM é diferencial'),
(4, 'Green Energy SA', 'Construção', 'Engenharia Civil', 'Engenheiro Civil para obras comerciais.',
'Detalhes: Supervisão técnica de obras, leitura e conferência de projetos, acompanhamento de cronogramas e gestão de equipes de campo. Responsável por controle de qualidade, segurança do trabalho e interface com clientes e fornecedores. Busca-se profissional com visão de processo, habilidade em resolução de conflitos e foco em entregas conforme especificações técnicas e normativas vigentes.',
'Formação em Engenharia Civil','Experiência em obras comerciais','Conhecimento em normas técnicas'),
(5, 'Construtora Futuro', 'Financeiro', 'Investimentos', 'Analista de Investimentos para área de risco.',
'Detalhes: Elaboração de análises de investimento, avaliação de risco e retorno, modelagem financeira e suporte à tomada de decisão estratégica. Atuação com consolidação de cenários, análise de indicadores e preparação de apresentações para diretoria. Espera-se domínio de modelagem em Excel, conhecimento de mercado e habilidade em comunicar resultados de forma clara e objetiva.',
'Formação em Economia/Finanças','Experiência em análise de investimentos','Habilidade em modelagem financeira'),
(6, 'Banco NextGen', 'Tecnologia', 'Segurança', 'Especialista em Segurança da Informação.',
'Detalhes: Implementação de políticas e controles de segurança, análise de vulnerabilidades, resposta a incidentes e condução de auditorias internas. Atuação em criptografia, gestão de acessos, logs e monitoramento contínuo. Colaboração com times de engenharia para embed de segurança no ciclo de desenvolvimento e aderência a normas e regulamentações do setor financeiro.',
'Certificação em segurança (Ex: CISSP/ISO)','Experiência em gestão de incidentes','Conhecimento em redes e criptografia'),
(7, 'DataTech Brasil', 'Administrativo', 'Gestão', 'Gerente Administrativo com foco em sustentabilidade.',
'Detalhes: Coordenação de áreas administrativas, contratação de fornecedores, otimização de processos e implementação de práticas sustentáveis no ambiente corporativo. Responsável por orçamentos, indicadores operacionais e projetos de economia de recursos, além de liderar iniciativas de compliance e bem-estar dos colaboradores.',
'Experiência em gestão administrativa','Conhecimento em práticas sustentáveis','Habilidade em planejamento e budgets'),
(8, 'EcoSustentável', 'Logística', 'Operações', 'Supervisor de Operações Logísticas.',
'Detalhes: Supervisão de equipe operacional, controle de indicadores de produtividade, gestão de embarques e recebimento, além de implementação de melhorias contínuas. Atuação voltada à redução de custos operacionais, garantia de SLA e adoção de processos mais sustentáveis na cadeia logística. Trabalho intensivo em chão de operação e comunicação com clientes.',
'Experiência em supervisão operacional','Conhecimento em KPIs logísticos','Liderança de equipes'),
(9, 'Logística Express', 'Educação', 'Desenvolvimento', 'Desenvolvedor de Sistemas Educacionais.',
'Detalhes: Desenvolvimento de plataformas e módulos para gestão educacional, integração com APIs externas e implementação de funcionalidades de acompanhamento pedagógico. Atuação com arquitetura de software, testes, deploy e manutenção, priorizando escalabilidade e usabilidade para escolas e cursos online. Valorizamos inovação, acessibilidade e foco em entrega de valor para o usuário final.',
'Experiência em desenvolvimento web','Conhecimento em integração de APIs','Foco em UX e escalabilidade'),
(10, 'EducaTech', 'Saúde', 'Gestão', 'Coordenador de Projetos em Saúde Digital.',
'Detalhes: Coordenação de projetos digitais para saúde, articulação entre times clínicos e técnicos, priorização de backlog e garantia de entregas com conformidade regulatória. Atuação inclui avaliação de impacto, testes de usabilidade e acompanhamento de indicadores de desempenho clínico e operacional. Perfil focado em comunicação, gestão de stakeholders e experiência em ambientes de saúde.',
'Experiência em gestão de projetos','Conhecimento em processos de saúde','Habilidade em comunicação'),
(10, 'Saúde Integral', 'Saúde', 'Tecnologia Médica', 'Analista de Sistemas para área hospitalar.',
'Detalhes: Suporte e desenvolvimento de sistemas para gestão hospitalar com foco em integração, segurança e continuidade operacional. Realizará análises de requisitos com equipes clínicas, implementação de melhorias, e testes funcionais. Conhecimento em protocolos de interoperabilidade e boas práticas de proteção de dados é fundamental, assim como capacidade de atuar sob pressão e em ambientes críticos.',
'Formação em TI com foco em saúde','Conhecimento em interoperabilidade','Experiência em ambientes hospitalares'),
(5, 'Construtora Futuro', 'Financeiro', 'Análise de Dados', 'Analista Financeiro júnior com foco em relatórios gerenciais.',
'Detalhes: Suporte na consolidação de dados financeiros, elaboração de relatórios gerenciais e controles orçamentários. Auxiliar na automação de relatórios, análise de variações e apoio em processos de fechamento mensal. Ambiente com mentoria, foco no desenvolvimento técnico e oportunidade de aprendizado em modelagem financeira e ferramentas de BI.',
'Formação em Administração/Finanças','Conhecimento básico em Excel avançado','Desejável noções de Power BI ou similar'),
(6, 'Banco NextGen', 'Tecnologia', 'Data Engineering', 'Engenheiro de Dados para pipelines e integração.',
'Detalhes: Construção e manutenção de pipelines de dados, ETL/ELT, otimização de storage e integração entre bancos relacionais e data lakes. Trabalho com equipes de ciência de dados para garantir dados limpos e versionados, implementação de testes de qualidade e monitoramento. Espera-se conhecimento em processamento distribuído, orquestração de workflows e boas práticas de governança de dados.',
'Experiência em ETL/ELT','Conhecimento em ferramentas de orquestração','Familiaridade com data lakes e warehouses'),
(7, 'DataTech Brasil', 'Tecnologia', 'QA', 'Analista de QA com foco em automação.',
'Detalhes: Planejamento e execução de testes automatizados e manuais, criação de scripts de automação, integração com pipelines CI/CD e garantia de qualidade das entregas. Responsável por manter suites de testes, reportar bugs e trabalhar próximo ao time de desenvolvimento para resolver regressões. Valorizamos atenção a detalhes, conhecimento em frameworks de teste e cultura de melhoria contínua.',
'Experiência em testes automatizados','Conhecimento em frameworks (Selenium, Cypress)','Habilidade em escrever casos de teste'),
(8, 'EcoSustentável', 'Projetos', 'Sustentabilidade', 'Consultor Ambiental júnior para projetos corporativos.',
'Detalhes: Apoio técnico em projetos de sustentabilidade corporativa, elaboração de indicadores de desempenho ambiental, ações de economia circular e programas de sensibilização interna. Atuação com levantamento de dados, apoio em certificações ambientais e comunicação com fornecedores para adoção de práticas sustentáveis. Oportunidade de crescimento e desenvolvimento em consultoria ambiental.',
'Formação em áreas ambientais','Noções de indicadores ambientais','Boa comunicação e trabalho em equipe');




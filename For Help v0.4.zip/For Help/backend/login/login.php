<link rel="shortcut icon" href="../midia/logo.png">
<?php
session_start();
require('../register/conn.php');

if(!empty($_POST)){
$mail = $_POST['mail'];
$password = $_POST['password'];
$username = $_POST['username'];

$try = mysqli_query($con,"SELECT*FROM cliente WHERE email_cliente='$mail' AND senha_cliente='$password' 
AND username_cliente = '$username'");
$cont = mysqli_num_rows($try);

if($try){
if($cont > 0 ){
    header('location:../../frontend/pages/index.php');
    $log = $_SESSION['log']=1;
}
else{
    header('location:../../frontend/pages/clientelogin.php');   
}
} 

else{
    echo 'Email ou Senha estão incorretos. tente novamente.';
    header('location:../../frontend/pages/clientelogin.php');
}
}
?>
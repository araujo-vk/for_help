<link rel="shortcut icon" href="../midia/logo.png">
<?php
session_start();
require('../register/conn.php');

if(!empty($_POST)){
$mail = $_POST['mail'];
$password = $_POST['password'];
$CNP = $_POST['CNPJ'];

$try = mysqli_query($con,"SELECT*FROM empresa WHERE contato_empresa='$mail' AND senha_empresa='$password' 
AND cnpj_empresa = '$CNP'");
$cont = mysqli_num_rows($try);

if($try){
if($cont > 0 ){
    header('location:../../frontend/pages/index.php');
    $log = $_SESSION['log']=1;
}
else{
    header('location:../../frontend/pages/empresalogin.php');   
}
} 

else{
    echo 'Email ou Senha estão incorretos. tente novamente.';
    header('location:../../frontend/pages/empresalogin.php');
}
}
?>
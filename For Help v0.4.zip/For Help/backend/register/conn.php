<?php
$con = mysqli_connect('localhost','root','9705Veno#','fourhelp');
if(!$con){
    echo 'O servidor não está respondendo corretamente. Aguarde ou tente novamente.';
}
?>
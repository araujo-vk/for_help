<?php session_start(); ?>
<?php
require('../conn.php');
$nombre = $_POST['nomeE'];
$telef = $_POST['telefoneE'];
$contato = $_POST['contato'];
$cnpj = $_POST['CNPJ'];
$pass = $_POST['senhaE'];

$grava = mysqli_query($con, "INSERT INTO empresa(nome_empresa, telefone_empresa, contato_empresa,
cnpj_empresa, senha_empresa) VALUES ('$nombre','$telef','$contato','$cnpj','$pass')");

$confirmar = mysqli_query($con, "SELECT*FROM empresa WHERE contato_empresa = '$contato' 
AND cnpj_empresa = '$cnpj' AND senha_empresa = '$pass'");
$confir = mysqli_num_rows($confirmar);

if($grava){
    if($confir > 0){
        header('location:../../../frontend/pages/index.php');
        $_SESSION['logado'] = 1;
        $_SESSION['if_company'] = 1;
    }
    
    else{
        echo 'Usuário, Telefone ou Email já existem.';
        header('location:../../../frontend/pages/registerCompany.php');
    }
    
} 
else {
    echo 'Houve uma falha ao cadastrar.';
    header('location:../../..frontend/pages/registerCompany.php');
}
?>
<?php
require('../../register/conn.php');
$id = $_POST['id'];
$nomeCo = $_POST['nomeCompany'];
$emailCo = $_POST['emailCompany'];
$cnpjCo = $_POST['cnpjCompany'];
$telefoneCo = $_POST['telefoneCompany']; 
mysqli_query($con,"UPDATE empresa SET nome_empresa = '$nomeCo', contato_empresa = '$emailCo', cnpj_empresa = '$cnpjCo', telefone_empresa = '$telefoneCo' WHERE id_empresa = '$id'");
    header('location:../../../frontend/pages/empresaProfile.php');

?>
<?php 
require('../../backend/register/conn.php');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <link rel="shortcut icon" href="../../logos/logo.ico">
    <?php
    session_start();
    if(isset($_SESSION['logado'])){
    $logado = $_SESSION['logado'];
    $logado = 1;
    }else{
    $logado = 0;
    }
    ?>
</head>
<body>
    <div id="header-container"></div>
        <div class="containerVB">
            <div class="PesquisaVB">
                <input type='text' placeholder="pesquisar vagas">
            </div>
            <div class="ResultadosVB">524.213 vagas encontradas.</div>
        
            <div class="vagasVB">
                <a href="vagaDetails.php"><?php
                    $j=1;
                    for($i = 0; $i < 20; $i++){?>
                            <?php
                            $procurar = mysqli_query($con, "SELECT * FROM vaga where id_vaga = '$j'");
                            $result = mysqli_fetch_array($procurar);
                            ?>
                           <a href="vagaDetails.php?id_vaga=<?php echo $j;?>"><div class="vaga">
                            <label class="label1"><?php echo $result['descricao_vaga']?></label>
                            <label class="label2"><?php echo $result['nome_empresa']?></label>
                            <label class="label3">local</label>
                            </div></a>
                            <div class="espacoEntreVagas"></div> 

                <?php 
                    $j++;
                }
                ?>
                </a>
        </div>
            </div>
    <div id="footer-container"></div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <link rel="shortcut icon" href="../../logos/logo.ico">
    <?php
    session_start();
    if(isset($_SESSION['logado'])){
    $logado = $_SESSION['logado'];
    $logado = 1;
    }else{
    $logado = 0;
    }
    ?>
</head>
<body>
    <div id="header-container"></div>
        <div class="container-devs">
            <div class="dev">
                <a href="https://github.com/araujo-vk"><img src="../images/VK.jpEg" class="img-dev"></a>
                <h2 class="dev-username">VK</h2>
                <p class="dev-name">Victor Oiveira Araújo</p>
            </div>
            <div class="dev">
                <a href="https://github.com/spaceYuyuki"><img src="../images/loren.jpeg" class="img-dev"></a>
                <h2 class="dev-username">Lorenzo</h2>
                <p class="dev-name">Lorenzo Marques Alves</p>
            </div>
            <div class="dev">
                <a href=""><img src="../images/anna.jpeg" class="img-dev"></a>
                <h2 class="dev-username">Anna</h2>
                <p class="dev-name">Anna Alice Alustau Siqueira</p>
            </div>
            <div class="dev">
                <a href="https://github.com/Obatinha"><img src="../images/obata.jpeg" class="img-dev"></a>
                <h2 class="dev-username">Obata</h2>
                <p class="dev-name">Giovanni Oliveira Obata</p>
            </div>
        </div>
    <div id="footer-container"></div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>
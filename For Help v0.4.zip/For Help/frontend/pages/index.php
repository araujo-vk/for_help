<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ForHelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <link rel="shortcut icon" href="../../logos/logo.ico">
    <?php
session_start();
if(isset($_SESSION['logado'])){
$logado = $_SESSION['logado'];
$logado = 1;
}else{
    $logado = 0;
}
?>
</head>
<body>
    <div id="header-container"></div>
    <div class="container">
        <div class="section-title">Do que você precisa hoje?</div>
        <div class="card-row">
            <div class="card">
                    <a href="vagaBrowser.php"><img src="../images/vagas.png" alt="Vagas" style="width:100%;max-width:300px;"></a>
                    <div class=vagas_p><p>Vagas</p></div>
            </div>
            <div class="card">
                <a href="emDesenvolvimento.php"><img src="../images/cursos.png" alt="Cursos" style="width:100%;max-width:300px;"></a>
                <div class="cursos_p"><p>Cursos</p></div>
            </div>
        </div>

        <div class="section-title">Sobre a For Help</div>
        <div class="card-row">
            <div class="card">
                <a href="forhelp.php"><img src="../images/Logo (1).png" alt="For Help" style="width:300px;"></a>
            </div>
            <div class="card">
            <p style="font-size: 1.2rem; text-align: justify; line-height: 1.6;">
            A For Help é um projeto criado por estudantes, visando ajudar outros estudantes a atingirem seus objetivos acadêmico-profissionais, através de maior contato com empresas, com cursos e vagas voltadas para jovens.
            </p>

            </div>
        </div>

        <div class="card-row">
            <div class="card">
                <img src="../images/bartotec.png" alt="Etec Bartô" style="width: 300px;">
            </div>
        </div>
        <div class="section-title"><a href="aEquipe.php">Conheça a equipe →</a></div>
        <div class="espaço_extra"></div>
    </div>
    <div id="footer-container"></div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>
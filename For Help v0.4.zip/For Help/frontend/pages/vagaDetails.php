<?php 
require('../../backend/register/conn.php');
$id_vaga = $_GET['id_vaga'];
$procurar = mysqli_query($con, "SELECT * FROM vaga WHERE id_vaga = '$id_vaga'");
$result = mysqli_fetch_array($procurar);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <link rel="shortcut icon" href="../../logos/logo.ico">
    <?php
    session_start();
    if(isset($_SESSION['logado'])){
    $logado = $_SESSION['logado'];
    $logado = 1;
    }else{
    $logado = 0;
    }
    ?>
</head>
<body>
    <div id="header-container"></div>
        <div class="containerVD">
            <div class="detalhesVaga">
                <h2><?php echo $result['descricao_vaga'] ?></h2>
                <h3><?php echo $result['nome_empresa'] ?></h3>
                <br><a href="https://youtu.be/XEFZ30Cvdnc?si=C_-sleAA4_xuSawX&t=9"><img src="../images/vagas.png"></a><br><br>
                <h4>Descrição da Vaga:</h4>
                <p><?php echo $result['detalhes_vaga'] ?></p>
                <h4>Requisitos:</h4>
                <ul>
                    <li><?php echo $result['req1'] ?></li>
                    <li><?php echo $result['req2'] ?></li>
                    <li><?php echo $result['req3'] ?></li>
                </ul>
                <button>Candidatar-se</button>
            </div>
        </div>
    <div id="footer-container"></div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>
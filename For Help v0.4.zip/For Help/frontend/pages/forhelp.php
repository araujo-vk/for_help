<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <link rel="shortcut icon" href="../../logos/logo.ico">
    <?php
    session_start();
    if(isset($_SESSION['logado'])){
    $logado = $_SESSION['logado'];
    $logado = 1;
    }else{
    $logado = 0;
    }
    ?>
</head>
<body>
    <div id="header-container"></div>
        <div class="container-forHelp">
            <div class="card-ForHelp-projeto">
                <h2 class="card-forHelp-title">O Projeto</h2>
                <p class="card-forHelp-text">A For Help é um projeto criado para a BartoTec 2025, que visa conectar jovens ao mercado de trabalho
                    de maneira simples e eficaz, através de oportunidades de emprego e cursos.
                </p>
            </div>
            <div class="card-ForHelp-equipe">
                <h2 class="card-forHelp-title">A Equipe</h2>
                <p class="card-forHelp-text">
                    <div class="mano">Victor Oliveira Araújo</div>
                    <div class="mano">Lorenzo Marques Alves</div>
                    <div class="mano">Anna Alice Alustau Siqueira</div>
                    <div class="mano">Giovanni Oliveira Obata</div>
                </p>
            </div>
            <div class="card-ForHelp-BartoTec">
                <h2 class="card-forHelp-title">BartoTec</h2>
                <p class="card-forHelp-text">A BartoTec é uma feira administrada pela ETEC Bartolomeu Bueno da Silva - Anhanguera, onde alunos expõem projetos desenvolvidos em grupo 
                    para vários outros alunos, várias empresas e para seus professores, projetos esses que visam por à mostra tudo que aprenderam nos ultimos anos.
                </p>
            </div>
        </div>
        <a href="https://www.youtube.com/watch?v=2NAylJZo698"><div class="nadadiscreto"></div></a>
    <div id="footer-container"></div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>
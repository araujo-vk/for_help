<?php 
require('../../backend/register/conn.php');
$query = mysqli_query($con, "SELECT id_cliente, nome_cliente, username_cliente, email_cliente,
telefone_cliente, idade_cliente FROM cliente");

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <link rel="shortcut icon" href="../../logos/logo.ico">
    <?php
    session_start();
    if(isset($_SESSION['logado'])){
    $logado = $_SESSION['logado'];
    $logado = 1;
    }else{
    $logado = 0;
    }
    ?>
</head>
<body>
    <div id="header-container"></div>
    <div class="container-perfil">
        <h2>Perfil do Usuário</h2>
        <div class="profile-personalizacao">
            <h2>Personalização</h2>
            <img src="../assets/user.png" alt="Foto de Perfil" class="profile-picture">
            <a href="https://youtu.be/FQdmWe5R2WM?si=baGby0BXveic4wYP"><button class="change-picture-btn">Alterar Foto</button></a>
            <div class="bio-section">
                <h3>Bio</h3>
                <textarea placeholder="Escreva uma breve biografia..."></textarea>
                <button class="save-bio-btn">Salvar Biografia</button>
            </div>
        </div>
        <div class="profile-dados-pessoais">
            <h2>Dados Pessoais</h2>
            <?php while($mostrar = mysqli_fetch_array($query)){?>
            <p class="profile-info" id="nome"><?php echo $mostrar['nome_cliente'];?></p>
            <p class="profile-info" id="username"><?php echo $mostrar['username_cliente'];?></p>
            <p class="profile-info" id="email"><?php echo $mostrar['email_cliente'];?></p>
            <p class="profile-info" id="telefone"><?php echo $mostrar['telefone_cliente'];?></p>
            <p class="profile-info" id="data_nascimento"><?php echo $mostrar['idade_cliente'];?></p>
            <button class="edit-personal-info-btn"><a href="updUser.php?id=<?php echo $mostrar['id_cliente']?>">Editar Informações Pessoais</a></button>
            <?php
        }
        ?>
        </div>
        <div class="profile-carreira">
            <h2>Carreira</h2>
            <p class="profile-info" id="formacao">Formações do usuário</p>
            <p class="profile-info" id="experiencia">Nivel de Experiencia</p>
            <p class="profile-info" id="habilidades">Competencias do usuário</p>
        </div>
        <div class="profile-opcoes">
            <h2>Opções</h2>
            <p class="random-ahh-disclaimer"> (W.I.P) - seção sendo trabalhada</p>
        </div>
        <div class="profile-segurança">
            <h2>Segurança</h2>
            <a href="changePassword.php" class="change-password-link">Alterar Senha</a>
        </div>
        <div class="profile-sair">
            <button class="logout-btn"><a href="pickAccountTypeLogin.php">Sair da Conta</a></button>
        </div>
    </div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
            //colocar o codigo de redirecionar para a página de login se não estiver logado
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
    </script>
    <div id="footer-container"></div>
    <script>
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
    <!-- 
     <form>
                <input type="text" id="nome" name="nome" placeholder="Fulanoh">
                <input type="text" id="username" name="username" placeholder="xX_fulano_Xx">
                <input type="text" id="nome" name="email" placeholder="fulano@email.com">
                <input type="text" id="nome" name="telefone" placeholder="(69) 99705-9705">
                <input type="text" id="nome" name="data_aniversario" placeholder="9705-05-05">
                <input type="submit">
            </form>
            
    (Caso dê merda a tentativa do loren)
    -->
</body>
</html>
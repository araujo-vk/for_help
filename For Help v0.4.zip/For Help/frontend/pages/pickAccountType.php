<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../../logos/logo.ico">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
</head>
<body>
    <div id="header-container"></div>
    <div class="container-pickAccountType">
        <h2>Selecione o tipo de conta:</h2>
        <div class="account-type-buttons">
            <a href="registerUser.php" class="account-type-btn">Estudante</a>
            <a href="registerCompany.php" class="account-type-btn">Empresarial</a>
        </div>
        <div class="login-register">
            Já é membro? <a href="PickAccountTypeLogin.php">Faça o Login</a>
        </div>
    </div>
    <a href="../images/eggman-outcome-memories.gif"><div class="nadadiscreto"></div></a>
    <div id="footer-container"></div>
    <script>
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>
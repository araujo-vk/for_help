<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../midia/logo.png">
    <title>Processando...</title>
</head>
<body>
    
</body>
</html>

<?php
require('../conn.php');
$nome = $_POST['nome'];
$email = $_POST['email'];
$usuario = $_POST['usuario'];
$telefone = $_POST['telefone'];
$senha = $_POST['senha'];
$idade = $_POST['idade'];
$image = 'midia/';
$curriculo = $image.basename($_FILES['curriculo']['name']);
move_uploaded_file($_FILES['curriculo']['tmp_name'], $curriculo);

$insert = mysqli_query($con,"INSERT INTO cliente(nome_cliente, email_cliente, username_cliente,
telefone_cliente, senha_cliente, idade_cliente, curriculo_cliente) VALUES ('$nome','$email',
'$usuario','$telefone','$senha','$idade','$curriculo')");

if($insert){
    header('location:../../../frontend/placeholder.php');
} else {
    echo 'Houve uma falha ao cadastrar.';
    header('location:register.html');
}
?>
<?php
session_start();
$id_usuario = $_SESSION['id_usuario'];
$username = $_SESSION['username'];
?>
<div class="header">
    <div class="logo">
        <a href="../pages/index.html"><img src="../../logos/logo.png" alt="ForHelp Logo"></a>
    </div>
    <div class="links">
        <div class="link"><a href="../pages/userProfile.php">Olá, <?php echo $username; ?></a></div>
        <div class="link"><a href="../pages/vagaBrowser.php">Vagas</a></div>
    </div>
</div>
<?php
session_start();
$id_usuario = $_SESSION['id_usuario'];
$username = $_SESSION['username'];
?>
<div class="header">
    <div class="logo">
        <a href="../pages/index.html"><img src="../assets/logo.png" alt="ForHelp Logo"></a>
    </div>
    <div class="links">
        <div class="link"><a href="../pages/pickAccountType.html">Olá, <?php echo $username; ?></a></div>
    </div>
</div>
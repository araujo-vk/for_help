<link rel="shortcut icon" href="../midia/logo.png">
<?php
session_start();
require('../register/conn.php');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>For Help - Login</title>
</head>
<body>
    <form method='post' action='login.php'>
        <p>Email:</p><input type='email' name='mail'>
        <p>Senha:</p><input type='password' name='password'>
        <p>Conta Empresarial:<p><input type='checkbox' name='conta'><input type='checkbox' name='educar'>
        <input type='submit' value='Logar'>
    </form>
</body>
</html>
<?php
if(!empty($_POST)){
$mail = $_POST['mail'];
$password = $_POST['password'];
$conta = $_POST['conta'];
$educar = $_POST['educar'];

if(boolval($conta) == 1){
$try = mysqli_query($con,"SELECT*FROM empresa WHERE contato_empresa='$mail' AND senha_empresa='$password'");
$cont = mysqli_num_rows($try);
}
if(boolval($educar)== 1){
    $try = mysqli_query($con, "SELECT*FROM educador where email_educador='$mail' AND 
    senha_educador = '$password'");
    $cont = mysqli_num_rows($try);
}
else{$try = mysqli_query($con,"SELECT*FROM cliente WHERE email_cliente='$mail' AND senha_cliente='$password'");
$cont = mysqli_num_rows($try);}

if($cont > 0 ){
   $log = $_SESSION['log']=1;
    header('location:../../frontend/placeholder.php');
} else{
    echo 'Email ou Senha estão incorretos. tente novamente.';
}
}
?>
<?php session_start(); ?>
<?php
require('../conn.php');
$nombre = $_POST['nomeE'];
$telef = $_POST['telefoneE'];
$contato = $_POST['contato'];
$cnpj = $_POST['CNPJ'];
$pass = $_POST['senhaE'];

$grava = mysqli_query($con, "INSERT INTO empresa(nome_empresa, telefone_empresa, contato_empresa,
cnpj_empresa, senha_empresa) VALUES ('$nombre','$telef','$contato','$cnpj','$pass')");

if($grava){
    header('location:../../../frontend/placeholder.php');
} else {
    echo 'houve falha ao cadastrar. tente novamente.';
    header('location:empresas.html');
}
?>
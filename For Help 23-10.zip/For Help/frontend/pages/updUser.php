<?php 
require('../../backend/register/conn.php');
$id = $_GET['id'];
$procurar = mysqli_query($con, "SELECT * FROM cliente WHERE id_cliente = '$id'");
$result = mysqli_fetch_array($procurar);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <?php
    session_start();
    if(isset($_SESSION['logado'])){
    $logado = $_SESSION['logado'];
    $logado = 1;
    }else{
    $logado = 0;
    }
    ?>
</head>
<body>
    <div id="header-container"></div>
        <div class="updUser-container">
            <form action="../../backend/report/cliente/updateCliente.php" method="POST">
                <input type="hidden" name="id" value="<?php echo $result['id_cliente']?>">
                <label>Atualizar Nome:</label><br>
                <input type="text" name="nomeCliente" placeholder="<?php echo $result['nome_cliente']?>"><br><br>
                <label>Atualizar Username:</label><br>
                <input type="text" name="userCliente" placeholder="<?php echo $result['username_cliente']?>"><br><br>
                <label>Atualizar Email:</label><br>
                <input type="email" name="emailCliente" placeholder="<?php echo $result['email_cliente']?>"><br><br>
                <label>Atualizar Telefone:</label><br>
                <input type="text" name="telefoneCliente" placeholder="(00) 00000-0000" placehoder="<?php echo $result['telefone_cliente']?>"><br><br>
                <button type="submit">Atualizar Informações</button>
            </form>
        </div>
    <div id="footer-container"></div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>

<?php
require('../../register/conn.php');
$id = $_POST['id'];
$nomeCl = $_POST['nomeCliente'];
$userCl = $_POST['userCliente'];
$emailCl = $_POST['emailCliente'];
$telefoneCl = $_POST['telefoneCliente']; 
mysqli_query($con,"UPDATE cliente SET nome_cliente = '$nomeCl', username_cliente = '$userCl', email_cliente = '$emailCl', telefone_cliente = '$telefoneCl' WHERE id_cliente = '$id'");
    header('location:../../../frontend/pages/userProfile.php');

?>
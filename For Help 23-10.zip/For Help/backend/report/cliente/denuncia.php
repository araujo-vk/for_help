<?php session_start(); 
$codigo = $_SESSION['codigo'];
$user = $_SESSION['user'];?>
<?php
require('../../register/conn.php');
$search = mysqli_query($con,"SELECT*FROM cliente WHERE id_cliente = '$codigo'");
$result = mysqli_fetch_array($search);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporta meu mano ai</title>
</head>
<body>
<form action='denuncia.php' method='post'>
    <p>Digite o motivo da denuncia:</p><input type='text' name='motivo'>
    <input type='submit' value='enviar denuncia'>
</form>
</body>
</html>

<?php
if(!empty($_POST)){
$motivo = $_POST['motivo'];
$register = mysqli_query($con,"INSERT INTO denuncias_usuario(id_cliente, username_cliente, motivo_denuncia)
VALUES ('$codigo','$user','$motivo')");

if(!$update){
    echo 'Não funcionou.';
} else{
    header('location:../../placeholder2.html');
}
}
?>
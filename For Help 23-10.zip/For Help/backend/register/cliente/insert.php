<?php session_start(); 
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../midia/logo.png">
    <title>Processando...</title>
</head>
<body>
    
</body>
</html>

<?php
require('../conn.php');
$nome = $_POST['nome'];
$email = $_POST['email'];
$usuario = $_POST['usuario'];
$telefone = $_POST['telefone'];
$senha = $_POST['senha'];
$idade = $_POST['idade'];


$insert = mysqli_query($con,"INSERT INTO cliente(nome_cliente, email_cliente, username_cliente,
telefone_cliente, senha_cliente, idade_cliente) VALUES ('$nome','$email',
'$usuario','$telefone','$senha','$idade')");

$select = mysqli_query("SELECT*FROM cliente WHERE username_cliente = '$usuario' 
AND email_cliente = '$email' AND telefone_cliente = '$telefone'");
$tentar = mysqli_num_rows($select);

if($insert){
    if($tentar > 0){
        header('location:../../../frontend/pages/index.php');
        $_SESSION['logado'] = 1;
        $_SESSION['if_company'] = 0;
    }
    else{
        echo 'Usuário, Telefone ou Email já existem.';
        header('location:../../../frontend/pages/registerUser.php');
    }
    
} else {
    echo 'Houve uma falha ao cadastrar.';
    header(header:'location:../../..frontend/pages/registerUser.php');
}

?>

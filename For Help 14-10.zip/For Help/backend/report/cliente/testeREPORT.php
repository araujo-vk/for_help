<?php session_start(); ?>
<?php
require('../../register/conn.php');
$resultado = mysqli_query($con,"SELECT*FROM cliente");


?>
    <table border=1>
        <tr>
            <td>ID do usuario</td>
            <td>Username do Usuario</td>
            <td>Email do Usuario</td>
            <td>Reportar</td>
        </tr>
        <?php
while($exibir = mysqli_fetch_array($resultado)){
    $id=$exibir['id_cliente'];
    $user=$exibir['username_cliente'];
    ?>
    <tr>
<td><?php echo "<b>".$exibir['id_cliente'];"</b>";?></td>
<td><?php echo $exibir['username_cliente'];?></td>
<td><?php echo $exibir['email_cliente'];?></td>
<td><a href="denuncia.php?id=<?php echo $id;?>">Reportar</a></td>
    </tr>
<?php
}
$_SESSION['codigo'] = $id;
$_SESSION['user'] = $user;
?>
    </table>
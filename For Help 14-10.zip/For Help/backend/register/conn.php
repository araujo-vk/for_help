<?php
$con = mysqli_connect('localhost','root','','fourhelp');
if(!$con){
    echo 'O servidor não está respondendo corretamente. Aguarde ou tente novamente.';
}
?>
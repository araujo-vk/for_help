<?php session_start(); ?>
<?php
require('../conn.php');
$nom = $_POST['nom'];
$passe = $_POST['passe'];
$courrier = $_POST['courrier'];

$enviar=mysqli_query($con,"INSERT INTO educador(nome_educador,email_educador,senha_educador) VALUES
('$nom','$courrier','$passe')");
if($enviar){
    header('location:../../../frontend/placeholder.php');
} else {
    echo 'houve falha ao cadastrar. tente novamente.';
    header('location:empresas.html');
}
?>
?>

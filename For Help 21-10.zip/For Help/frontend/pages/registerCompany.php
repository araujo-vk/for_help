<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <?php
    session_start();
    if(isset($_SESSION['logado'])){
    $logado = $_SESSION['logado'];
    $logado = 1;
    }else{
    $logado = 0;
    }
    ?>
</head>
<body>
    <div id="header-container"></div>
        <div class="container-registerCompany">
            <h2>Cadastro de Empresa</h2>
            <form action="../backend/registerCompany.php" method="POST" class="register-form">
                <label for="nome_empresa">Nome da Empresa:</label>
                <input type="text" id="nome_empresa" name="nome_empresa" required>

                <label for="contato_empresa">Email:</label>
                <input type="email" id="contato_empresa" name="contato_empresa" required>

                <label for="cnpj_empresa">CNPJ:</label>
                <input type="text" id="cnpj_empresa" name="cnpj_empresa" required>

                <label for="senha_empresa">Senha:</label>
                <input type="password" id="senha_empresa" name="senha_empresa" required>

                <label for="confirmar_senha_empresa">Confirmar Senha:</label>
                <input type="password" id="confirmar_senha_empresa" name="confirmar_senha_empresa" required>

                <button type="submit">Cadastrar</button>
            </form>
            <div class="login-register">
                Já tem conta? <a href="paginalogin.php">Faça o Login</a>
            </div>
            <div class="espaço_extra"></div>
        </div>
    <div id="footer-container"></div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>
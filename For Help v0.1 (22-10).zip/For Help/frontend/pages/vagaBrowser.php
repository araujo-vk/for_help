<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <link rel="shortcut icon" href="../../logos/logo.ico">
    <?php
    session_start();
    if(isset($_SESSION['logado'])){
    $logado = $_SESSION['logado'];
    $logado = 1;
    }else{
    $logado = 0;
    }
    ?>
</head>
<body>
    <div id="header-container"></div>
        <div class="containerVB">
            <div class="PesquisaVB">SearchAnswer</div>
            <div class="ResultadosVB">524.213 vagas encontradas.</div>
        
            <div class="vagasVB">
                <a href=""><?php
                    for($i = 0; $i < 10; $i++){
                      echo '
                        <a href="vagaDetails.php"><div class="vaga">
                            <label class="label1">Função da Vaga</label>
                            <label class="label2">Empresa</label>
                            <label class="label3">Local</label>
                            <img src="../images/placeholder.jpg" alt="Imagem da vaga">
                        </a></div>
                        <div class="espacoEntreVagas"></div>
                        ';  
                }
                ?>
                </a>
        </div>
            </div>
    <div id="footer-container"></div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>
<?php 
require('../../backend/register/conn.php');
$query = mysqli_query($con, "SELECT nome_empresa, contato_empresa,
cnpj_empresa, telefone_empresa FROM empresa");

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <?php
    session_start();
    if(isset($_SESSION['logado'])){
    $logado = $_SESSION['logado'];
    $logado = 1;
    }else{
    $logado = 0;
    }
    ?>
</head>
<body>
    <div id="header-container"></div>
        <div class="updEmpresa-container">
            <h2>Perfil do Usuário</h2>
        <div class="profile-personalizacao">
            <h2>Personalização</h2>
            <img src="../assets/user.png" alt="Foto de Perfil" class="profile-picture">
            <button class="change-picture-btn">Alterar Foto</button>
            <div class="bio-section">
                <h3>Bio</h3>
                <form>
                    <input type="text" placeholder="--baguidoido--"></input>
                    <input type="submit" value="Salvar Biografia"></input>
                </form>
            </div>
        </div>
        <div class="profile-dados-pessoais">
            <form>
                <?php while($mostrar = mysqli_fetch_array($query)){?>
                <input type="text" id="nome_empresa" placeholder="<?php echo $mostrar['nome_empresa']?>"></input>
                <input type="text" id="contato" placeholder="<?php echo $mostrar['contato_empresa']?>"></input>
                <input type="text" id="cnpj" placeholder="<?php echo $mostrar['nome_empresa']?>"></input>
                <input type="text" id="telefone" placeholder="<?php echo $mostrar['telefone_empresa']?>"></input>
                <input type="submit" id="subimisso" value="Atualizar"></input>
            </form>
            <?php } ?>
        </div>
        <div class="profile-ramo">
            <h2>Carreira</h2>
            <p class="profile-info" id="formacao"></p>
            <p class="profile-info" id="experiencia"></p>
            <p class="profile-info" id="habilidades"></p>
            <button class="edit-career-info-btn">Editar Informações de Carreira</button>
        </div>
        <div class="profile-opcoes">
            <h2>Opções</h2>
            <p class="random-ahh-disclaimer"> (W.I.P) - seção sendo trabalhada</p>
        </div>
        <div class="profile-segurança">
            <h2>Segurança</h2>
            <form>
                <label>Senha atual: <?php echo $mostrar['senha_empresa']?><!-- NOTA para quem for corrigir isso: SIM, É UMA FALHA ABSURDA DE SEGURANÇA, MAS POR PURA LUDICIDADE NA FEIRA, VAMOS EXIBIR A SENHA COMO NADA ESTIVESSE ACONTECENDO. OBRIGADO PELA COMPREENSÃO. ASS: VK --></label>
                <input type="password" id="senha_nova" placeholder="Nova senha"></input>
                <input type="password" id="senha_repetida" placeholder="Insira novamente a nova senha:"></input>
                <input type="submit" value="Enviar"></input>
            </form>
        </div>
        <div class="profile-sair">
            <button class="logout-btn">Sair da Conta</button>
        </div>
        </div>
    <div id="footer-container"></div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>
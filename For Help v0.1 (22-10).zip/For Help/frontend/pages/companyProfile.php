<?php 
require('../../backend/register/conn.php');
$query = mysqli_query($con, "SELECT nome_empresa, contato_empresa,
cnpj_empresa, telefone_empresa FROM empresa");

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <link rel="shortcut icon" href="../../logos/logo.ico">
    <?php
    session_start();
    if(isset($_SESSION['logado'])){
    $logado = $_SESSION['logado'];
    $logado = 1;
    }else{
    $logado = 0;
    }
    ?>
</head>
<body>
    <div id="header-container"></div>
    <div class="container-perfil">
        <h2>Perfil do Usuário</h2>
        <div class="profile-personalizacao">
            <h2>Personalização</h2>
            <img src="../assets/user.png" alt="Foto de Perfil" class="profile-picture">
            <button class="change-picture-btn">Alterar Foto</button>
            <div class="bio-section">
                <h3>Bio</h3>
                <textarea placeholder="Escreva uma breve biografia..."></textarea>
                <button class="save-bio-btn">Salvar Biografia</button>
            </div>
        </div>
        <div class="profile-dados-pessoais">
            <h2>Dados Pessoais</h2>
            <?php while($mostrar = mysqli_fetch_array($query)){?>
            <p class="profile-info" id="nome_company" placeholder="nome empresa"><?php echo $mostrar['nome_empresa']?></p>
            <p class="profile-info" id="email_company" placeholder="email@gmail.com"><?php echo $mostrar['contato_empresa']?></p>
            <p class="profile-info" id="CNPJ_company" placeholder="00.000.000/0000-00"><?php echo $mostrar['cnpj_empresa']?></p>
            <p class="profile-info" id="Telefone_company" placeholder="(11) 99123-4312"><?php echo $mostrar['telefone_empresa']?></p>
            <button class="edit-personal-info-btn">Editar Informações da Empresa</button>
        </div>
        <?php
            }
        ?>
        <div class="profile-ramo">
            <h2>Carreira</h2>
            <p class="profile-info" id="formacao"></p>
            <p class="profile-info" id="experiencia"></p>
            <p class="profile-info" id="habilidades"></p>
            <button class="edit-career-info-btn">Editar Informações de Carreira</button>
        </div>
        <div class="profile-opcoes">
            <h2>Opções</h2>
            <p class="random-ahh-disclaimer"> (W.I.P) - seção sendo trabalhada</p>
        </div>
        <div class="profile-segurança">
            <h2>Segurança</h2>
            <a href="updEmpresa.php" class="change-password-link">Alterar Senha</a>
        </div>
        <div class="profile-sair">
            <button class="logout-btn">Sair da Conta</button>
        </div>
    </div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
            //colocar o codigo de redirecionar para a página de login se não estiver logado
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
    </script>
    <div id="footer-container"></div>
    <script>
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>

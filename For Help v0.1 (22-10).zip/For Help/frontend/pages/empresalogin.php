<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forhelp</title>
    <link rel="stylesheet" href="../styles/index.css">
    <link rel="shortcut icon" href="../../logos/logo.ico">
    <?php
    session_start();
    if(isset($_SESSION['logado'])){
    $logado = $_SESSION['logado'];
    $logado = 1;
    }else{
    $logado = 0;
    }
    ?>
</head>
<body>
    <div id="header-container"></div>
        <div class="container-login2">
            <h2>Login</h2>
            <form action="../../backend/login/loginempresa.php" method="POST" class="login-form">
                <label for="email">Email:</label>
                <input type="email" id="mail" name="mail" required>
                <label for="senha">Senha:</label>
                <input type="password" id="password" name="password" required>
                <label>CNPJ:</label>
                <input type="text" placeholder="00.000.000/0000-00" name="CNPJ">

                <button type="submit">Entrar</button>
            </form>
            <div class="login-register2">
                Não tem conta? <a href="pickAccountType.php">Faça o Cadastro</a>
            </div>
            <div class="espaço_extra"></div>
        </div>
    <div id="footer-container"></div>
    <script>
        if (<?php echo $logado; ?> === 1) {
            fetch('../assets/headerLogged.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                });
        } else {
        fetch('../assets/headerUnlogged.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
            });
        }
        fetch('../assets/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            });
    </script>
</body>
</html>
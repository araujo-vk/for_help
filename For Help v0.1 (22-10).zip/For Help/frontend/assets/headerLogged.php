<?php
session_start();
if($_SESSION['if_company'] == 1){
    $username = $_SESSION['nomeE'];
}else{
    $username = $_SESSION['usuario'];
}
?>
<div class="header">
    <div class="logo">
        <a href="../pages/index.html"><img src="../../logos/logo.png" alt="ForHelp Logo"></a>
    </div>
    <?php 
    if ($if_company == 0) {
        ?>  <div class="links">
                <div class="link"><a href="../pages/userProfile.php">Olá, <?php echo $username; ?></a></div>
                <div class="link"><a href="../pages/vagaBrowser.php">Vagas</a></div>
            </div>
        <?php
    }else{
        ?>
        <div class="links">
            <div class="link"><a href="../pages/companyProfile.php">Olá, <?php echo $username; ?></a></div>
            <div class="link"><a href="../pages/vagaBrowser.php">Vagas</a></div>
        </div>
        <?php
    }
    ?>
</div>
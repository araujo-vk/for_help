create database fourhelp;
use fourhelp;

-- FOR HELP "Trabalho para a Bartotec ETEC Bratolomeu Bueno Da Silva 2025" --
/* -- Integrantes e Turma --
Membros: 
Anna Alice Alustau Siqueira
Giovanni Oliveira Obata
Lorenzo Marques Alves
Victor Oliveira Araújo

2° Informática para Internet - AMS - Grupo A
*/

/* -- Ideias centrais trabalhadas no Projeto --

! --> Plataforma onde jovens podem buscar contato melhor com empresas e buscar emprego 
! --> Caso tenhamos tempo, integrar no projeto um sistema de cursos

 >>> Tabelas: <<<

==> cliente {adm aqui}
==> empresa
==> vagas
==> geral

caso dê tempo:
	-> cursos
	-> docentes
*/

create table cliente (
id_cliente int not null auto_increment primary key,
nome_cliente varchar(128),
email_cliente varchar(128) not null,
username_cliente varchar(48) unique not null,
telefone_cliente varchar(15),
senha_cliente varchar(32) not null,
idade_cliente date,
curriculo_cliente varchar(64), -- arquivo
cursos_cliente varchar(256), -- arquivo(certificado) ou link, o back decide
if_admin bool -- ADMIN
);

create table empresa (
id_empresa int not null auto_increment primary key,
nome_empresa varchar(128) unique not null,
contato_empresa varchar(128),
cnpj_empresa varchar(18) not null, -- para o front e o back: usar isso para o cadastro + logien
senha_empresa varchar(32) not null,
telefone_empresa varchar(15)
);

create table vaga (
id_vaga int not null auto_increment primary key,
id_cliente int,
id_empresa int,
area_vaga varchar(64),
sub_area_vaga varchar(64),
descricao_vaga text,
foreign key (id_cliente) references cliente(id_cliente),
foreign key (id_empresa) references empresa(id_empresa)
);

create table educador (
id_educador int not null auto_increment primary key,
nome_educador varchar(128) not null,
email_educador varchar(128) not null,
senha_educador varchar(32) not null
);

create table curso (
id_curso int not null auto_increment primary key,
id_educador int,
nome_curso varchar(128) not null,
area_curso varchar(64),
sub_area_curso varchar(64),
horas_curso int,
aulas_curso varchar(128),
link_curso varchar(256),
foreign key (id_educador) references educador(id_educador)
);

create table denuncias_usuario(
id_denuncia int not null auto_increment primary key,
id_cliente int,
username_cliente varchar(128),
id_empresa int,
nome_empresa varchar(128),
id_educador int,
nome_educador varchar(128),
motivo_denuncia text,
foreign key (id_cliente) references cliente(id_cliente),
foreign key (id_empresa) references empresa(id_empresa),
foreign key (id_educador) references educador(id_educador)
);
select*from denuncias_usuario;
INSERT INTO empresa(nome_empresa,contato_empresa,cnpj_empresa,senha_empresa,telefone_empresa) values ('Proative', 'proative@gmail.com','12.432.543/4321-45','proative@@545','(11) 94123-4324');
INSERT INTO cliente(nome_cliente,email_cliente,username_cliente,telefone_cliente,senha_cliente,idade_cliente) values
('Lorenzo Marques Alves','lorenzo.alves01@etec.sp.gov.br','Lorenzo','(11) 99181-7819','Lorenzo@@345','2009-01-31');
-- create table geral (); --> depois do php, se necessário

